<?php 

$servername = "localhost";
$username = "1092449";
$password = "wordpress25";
$dbname = "1092449";

$conn = mysqli_connect($servername, $username, $password, $dbname);
