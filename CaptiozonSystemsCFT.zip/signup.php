
</DOCTYPE html>

<head></head>
<body>


<form action="fz.php" method="POST">
<input type="text" name="name" placeholder="name">
<br>
<input type="text" name="email" placeholder="Email ID">
<br>
<input type="password" name="pass" placeholder="Password">
<br>

<button type="submit" name="submit">Sign Up</button>
</form>



</body>
</html>